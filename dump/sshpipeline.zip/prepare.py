import os
import time
import json
import glob
import argparse
import polars as pl
from pathlib import Path
from pprint import pprint
from datetime import datetime, date
from concurrent.futures import Future, wait
from dateutil.relativedelta import relativedelta
from typing import List, Dict, Tuple, Union, Callable, Optional

from util.func import write_parquet
from util.threads import init_threads, submit_task_io

_current_dir = Path(__file__).parent
_batch_codes: List[str] = None
_connection_str = "postgresql://{user}:{password}@{host}:{port}/{dbname}"
_default_batch = list(range(0, 256))

datetime_now = datetime.now()
timestamp_now = datetime_now.strftime('%Y%m%d%H%M%S')
next_state_map = {
    "batch_bid": "get_dtable",
    "get_dtable": "get_atable",
    "get_atable": "get_ftable",
    "get_ftable": "done",
    "done": "done"
}

state_order_map = {
    "batch_bid": 0,
    "get_dtable": 1,
    "get_atable": 2,
    "get_ftable": 3,
    "done": 4
}

map_data_type = {
    'Utf8': pl.Utf8,
    'Float32': pl.Float32,
    'Float64': pl.Float64,
    'Int8': pl.Int8,
    'Int16': pl.Int16,
    'Int32': pl.Int32,
    'Int64': pl.Int64,
    'Date32': pl.Date,
    'Date': pl.Date,
    'Boolean': pl.Boolean
}


def _get_batch_codes() -> List[str]:
    global _batch_codes

    if _batch_codes is not None:
        return _batch_codes

    h = "0123456789abcdef"
    _batch_codes = []
    for x in h:
        for y in h:
            _batch_codes.append(x+y)

    return _batch_codes


def _clean_bids(bids: List[str]) -> List[str]:
    bids = [bid.strip().strip("'").strip() for bid in bids]
    bids = [bid for bid in bids if bid and bid != '' and bid is not None]

    return bids


def _get_cycle_list(cycle_start: int, cycle_end: int) -> List[int]:
    cycle1, cycle2 = str(cycle_start), str(cycle_end)
    if (len(cycle1) != 6 or not cycle1.startswith("20")) or (len(cycle2) != 6 or not cycle2.startswith("20")):
        raise Exception("Cycle format should be YYYYMM (e.g 202312)")

    year_start = cycle_start // 100
    year_end = cycle_end // 100

    if year_start == year_end:
        return list(range(cycle_start, cycle_end + 1))

    cycles = list(range(cycle_start, year_start * 100 + 12 + 1))
    for year in range(year_start + 1, year_end):
        cycle = list(range(year * 100 + 1, year * 100 + 12 + 1))
        cycles.extend(cycle)

    cycles.extend(list(range(year_end * 100 + 1, cycle_end + 1)))

    return cycles


def cast_schema(data: Union[pl.DataFrame, pl.LazyFrame], schema: dict) -> Union[pl.DataFrame, pl.LazyFrame]:
    data = (
        data
        .with_columns(
            [
                pl.col(x['name']).cast(map_data_type[x['data_type']], strict=False)
                for x in schema['fields']
                if x['data_type'] not in ['Date', 'Date32']
            ] + [
                pl.col(x['name']).str.strptime(pl.Date, format='%Y-%m-%d').cast(map_data_type[x['data_type']], strict=False)
                for x in schema['fields']
                if x['data_type'] in ['Date', 'Date32']
            ]
        )
    )

    return data


def get_bid_hashed(
    filepath: str,
    rawdata_path: str, 
    update: bool = False,
    timestamp: str = timestamp_now
) -> str:
    """
    Getting all bid and its hashed version
    If update = True then force update
    If update = False -> check if the last modified < 7 days then no update else update
    return: str filepath of bid_hashed parquet
    """
    file_save = f"{filepath}/bid_hashed.parquet"

    if not update and os.path.exists(file_save):
        # get delta between now and last modified time
        previous_file = datetime.fromtimestamp(os.path.getmtime(file_save))
        delta = datetime_now - previous_file
        print(delta.total_seconds())
        if delta.total_seconds() < 24 * 3600 * 30:
            return file_save

    if not os.path.exists(filepath):
        os.makedirs(filepath)

    bimt = pl.scan_parquet(f'{rawdata_path}/bimt/updated_timestamp_partition=*/data*.parquet')
    if os.path.exists(file_save) and timestamp_now == timestamp:
        # for better optimization as we already have previous latest version of each row
        bimt_prev = pl.scan_parquet(file_save)
        max_updated_timestamp = bimt_prev.select(['updated_timestamp']).max().collect()['updated_timestamp'].item()

        # concat guarantee the order is maintained
        bimt = pl.concat([
            bimt_prev,
            # only getting new data beyond previous latest version
            bimt.filter(pl.col('updated_timestamp') > max_updated_timestamp).sort(['updated_timestamp'])
        ])
    else:
        # use original method
        bimt = bimt.filter(pl.col('updated_timestamp') <= timestamp).sort(['updated_timestamp'])

    start_time = time.time()
    unique_col = ['member_type', 'member_code', 'cif']
    bimt = bimt.unique(subset=unique_col, keep="last")

    bimt.collect().write_parquet(file_save)
    print(f"Finished retrieving all bid hashed in {time.time() - start_time}s")

    return file_save


def batch_bid(filepath: str, rawdata_path: str, update: bool = False, timestamp: str = timestamp_now, batches: List[int] = _default_batch):
    bid_hashed_path = get_bid_hashed(filepath, rawdata_path, update=update, timestamp=timestamp)
    bid_hashed = pl.scan_parquet(bid_hashed_path)

    for i_batch in batches:
        batch_code = "{:02x}".format(i_batch)
        path_save = f"{filepath}/rawdata_batch/batch{i_batch}"
        if not os.path.exists(path_save):
            os.makedirs(path_save)
        
        start_time = time.time()

        bid_temp = (
            bid_hashed
            .filter(pl.col("batch") == batch_code)
            .sort(['bid1'])
        )

        bid_temp.collect().write_parquet(f"{path_save}/bid_hashed_batch{i_batch}.parquet", use_pyarrow=True)

        print(f"Finished batch {i_batch} in {time.time() - start_time}s", end='\r')


def get_atable(
    key_table: Union[pl.LazyFrame, str],
    path_save: str,
    rawdata_path: str,
    timestamp: str = timestamp_now,
    is_poc: bool = False,
) -> Future:
    col_key = ['member_type', 'member_code', 'cif']
    if type(key_table) == str:
        key_table = pl.scan_parquet(key_table)

    if is_poc:
        key_table = key_table.select(col_key + ["bid1", "t_observe"]).unique()
        timestamp_filter = pl.col('t_observe').dt.truncate("1mo").dt.offset_by("1mo").dt.strftime('%Y%m%d%H%M%S')
    else:
        key_table = key_table.select(col_key + ["bid1"]).unique()
        timestamp_filter = pl.lit(timestamp)

    unique_col = ['member_type', 'member_code', 'cif', 'account_number']
    atable = (
        pl.scan_parquet(f"{rawdata_path}/atable/updated_timestamp_partition=*/data*.parquet")
        .join(
            key_table.select(col_key).unique(),
            on=col_key,
            how='inner',
        )
        .filter(pl.col('updated_timestamp') <= timestamp_filter)
        .sort(unique_col + ['updated_timestamp'])
        .unique(subset=unique_col, keep="last")
    )

    atable = (
        atable
        .sort(['member_type', 'member_code', 'cif', 'account_number'])
        .collect()
    )

    future = submit_task_io(write_parquet, atable.clone(), path_save)

    return future


def get_atable_all(filepath: str, rawdata_path: str, timestamp: str = timestamp_now, batches: List[int] = _default_batch):
    for i_batch in batches:
        path_save = f"{filepath}/rawdata_batch/batch{i_batch}"
        if not os.path.exists(path_save):
            os.makedirs(path_save)

        start_time = time.time()
        get_atable(
            key_table=f"{path_save}/bid_hashed_batch{i_batch}.parquet",
            path_save=f"{path_save}/atable_batch{i_batch}.parquet",
            rawdata_path=rawdata_path,
            timestamp=timestamp
        )
        print(f"Finished get atable batch {i_batch} in {time.time() - start_time}s", end='\r')


def get_dtable(
    key_table: Union[pl.LazyFrame, str],
    path_save: str,
    rawdata_path: str,
    timestamp: str = timestamp_now,
    is_poc: bool = False,
    dtable_poc_path: str = 'public'
) -> Future:
    data_path = f"{rawdata_path}/dtable/updated_timestamp_partition=*/data*.parquet"
    all_data_list = glob.glob(data_path)

    if type(key_table) == str:
        key_table = pl.scan_parquet(key_table)

    unique_col = ['bid1', 'member_type', 'member_code', 'cif']
    order_col = ['create_date', 'cycle_date']
    if is_poc:
        schema = json.load(open(f"{_current_dir}/resources/schema_dtable.json"))
        dtable = (
            pl.scan_csv(dtable_poc_path, infer_schema_length=0, separator="|")
            .rename(
                {
                    "bid": "bid1",
                    "kode_jenis_pelapor": "member_type",
                    "kode_pelapor": "member_code",
                    "tahun_bulan_data": "cycle_date",
                    "nomor_cif_debitur": "cif",
                    "jenis_identitas": "id_type",
                    "nomor_identitas": "id_number",
                    "nomor_telepon": "cellular",
                    "kode_status_pendidikan": "education",
                    "jenis_kelamin": "gender",
                    "tanggal_lahir": "dob",
                    "kode_kabupaten_atau_kota": "city",
                    "kode_pekerjaan": "employment",
                    "status_perkawinan_debitur": "marital_status",
                }
            )
            .select(unique_col + ['create_date', 'dob', 'city', 'gender', 'marital_status', 'education', 'employment', 'id_type', 'id_number', 'cellular', 'update_date', 'cycle_date'])
            .with_columns([
                pl.col("gender").map_dict({"L": 1, "P": 2, "B": 3, "M": 4}, default=-1)
            ])
        )

        dtable = (
            dtable
            .pipe(cast_schema, schema=schema)
            .join(key_table.select(['bid1', 't_observe']), on=['bid1'], how='inner')
        )

    else:
        bid_temp = key_table.select(pl.col("bid1")).collect()
        bid_list = _clean_bids(bid_temp["bid1"].unique().to_list())

        lf_list = []
        for file in all_data_list:
            dtable_temp = (
                pl.scan_parquet(file)
                .select(unique_col + ['create_date', 'dob', 'city', 'gender', 'marital_status', 'education', 'employment', 'updated_timestamp', 'cycle_date'])
                .filter(
                    (pl.col('bid1').is_in(bid_list)) & (pl.col('updated_timestamp') <= timestamp)
                )
                .sort(['updated_timestamp'] + order_col)
                .unique(subset=unique_col, keep="last")
            )
            lf_list.append(dtable_temp)

        dtable: pl.LazyFrame = pl.concat(lf_list)

    dtable = (
        dtable
            .with_columns([
            pl.col('create_date').alias('create_date_raw'),
            pl.col("create_date").str.slice(0, 8).alias('create_date'),
        ])
        .sort(unique_col)
        .collect()
    )
    future = submit_task_io(write_parquet, dtable.clone(), path_save)

    return future


def get_dtable_all(filepath: str, rawdata_path: str, timestamp: str = timestamp_now, batches: List[int] = _default_batch):

    for i_batch in batches:
        path_save = f"{filepath}/rawdata_batch/batch{i_batch}"
        if not os.path.exists(path_save):
            os.makedirs(path_save)

        start_time = time.time()
        get_dtable(
            key_table=f"{path_save}/bid_hashed_batch{i_batch}.parquet",
            path_save=f"{path_save}/dtable_batch{i_batch}.parquet",
            rawdata_path=rawdata_path,
            timestamp=timestamp,
        )
        print(f"Finished get dtable batch {i_batch} in {time.time() - start_time}s", end='\r')


def get_ftable(
    key_table: Union[pl.LazyFrame, str],
    path_save: str,
    rawdata_path: str,
    cycle_list: List[int],
    timestamp: str = timestamp_now,
    is_poc: bool = False
) -> List[Future]:
    """
    dtable: The Dtable or Dtable path, will convert to Lazyframe if it isn't
    path_save: Path save of the F table
        e.g: /home/ds-1/db_dump/parquet/*/date.parquet
    cycle_list: The list of cyle range need to be retrieved
        e.g: cycle_list = (
                list(range(201910, 201912 + 1))
                + list(range(202001, 202006 + 1))
                + list(range(202007, 202012 + 1))
                + list(range(202101, 202112 + 1))
                + list(range(202201, 202212 + 1))
            )
    """
    col_key = ["member_type", "member_code", "cif"]
    if type(key_table) == str:
        key_table = pl.scan_parquet(key_table)

    if is_poc:
        key_table = key_table.select(col_key + ["bid1", "t_observe"]).unique()
        timestamp_filter = pl.col('t_observe').dt.truncate("1mo").dt.offset_by("1mo").dt.strftime('%Y%m%d%H%M%S')
    else:
        key_table = key_table.select(col_key + ["bid1"]).unique()
        timestamp_filter = pl.lit(timestamp)

    # ftable
    future_list = []
    for cycle in cycle_list:
        print(f"Processing cycle {cycle}", end="\r")

        data_path = f"{rawdata_path}/ftable/cycle_date_partition={cycle}/updated_timestamp_partition=*/data*.parquet"
        all_data_list = glob.glob(data_path)
        unique_cols = ["member_type", "member_code", "cif", "account_number"]

        ftable = pl.concat([
            pl.scan_parquet(file)
            .join(key_table, on=col_key, how='inner')

            for file in all_data_list
        ])

        ftable_temp = (
            ftable
            .filter(pl.col('updated_timestamp') <= timestamp_filter)
            .sort(['updated_timestamp'])
            .unique(subset=unique_cols, keep="last")
            .drop(["bid"])
            .rename({"defaultcode": "default_code"})
            .with_columns([
                pl.col("interest_rate").cast(pl.Float64),
                pl.col("dpd").cast(pl.Float64),
                pl.col("freq_arrears").cast(pl.Float64)
            ])
            .sort(['bid1', 'member_type', 'member_code', 'cif', 'account_number'])
            .collect()
        )

        fsave = f"{path_save}/cycle_date={cycle}/"
        os.makedirs(fsave, exist_ok=True)

        future_list.append(submit_task_io(write_parquet, ftable_temp.clone(), f"{fsave}/data.parquet"))
        # ftable_temp.collect().write_parquet(f"{fsave}/data.parquet", use_pyarrow=True)

    return future_list


def fix_ftable(filepath: str, batch: int):
    import json
    import shutil

    def cast_schema(data: Union[pl.DataFrame, pl.LazyFrame], schema: dict) -> Union[pl.DataFrame, pl.LazyFrame]:
        data = (
            data
            .with_columns(
                [
                    pl.col(x['name']).cast(map_data_type[x['data_type']], strict=False)
                    for x in schema['fields']
                    if x['data_type'] not in ['Date', 'Date32'] and x['name'] not in ['bid']
                ]
            )
        )

        return data

    col_order = [
        'member_type',
        'member_code',
        'cif',
        'usage_type',
        'cycle_date',
        'account_number',
        'condition',
        'init_credit_date',
        'maturity_date',
        'latest_restructure_date',
        'condition_date',
        'interest_rate',
        'init_limit',
        'out_balance',
        'default_code',
        'dpd',
        'collectability',
        'principal_arrears',
        'freq_arrears',
        'credit_type',
        'economic_sector',
        'debtor_category',
        'updated_timestamp',
        'bid1'
    ]
    cycle_ignore = [202202,202203,202204,202207,202208,202305,202307,202308,202309,202310,202311,202312,202401,202402,202403,202404,202405]
    schema = json.load(open(f"{_current_dir}/resources/schema_ftable.json"))
    start_time = time.time()

    for cycle in _get_cycle_list(202007, 202405):
        if cycle in cycle_ignore: continue

        path_ = f"{filepath}/rawdata_batch/batch{batch}/ftable_batch{batch}/cycle_date={cycle}"
        df = (
            pl.scan_parquet(f"{path_}/data.parquet")
            .rename({'default_code': 'defaultcode'})
            .pipe(cast_schema, schema)
            .rename({'defaultcode': 'default_code'})
            .with_columns([
                pl.col("interest_rate").cast(pl.Float64),
                pl.col("dpd").cast(pl.Float64),
                pl.col("freq_arrears").cast(pl.Float64)
            ])
            .with_columns(
                pl.lit('20240701000000').alias('updated_timestamp')
            )
            .select(col_order)
        )

        df.collect().write_parquet(f"{path_}/data_tmp.parquet")
        shutil.move(f"{path_}/data_tmp.parquet", f"{path_}/data.parquet")

    print(f"Finished fix ftable batch {batch} in {time.time() - start_time}s")


def get_ftable_all(filepath: str, rawdata_path: str, cycle_list: List[int], timestamp: str = timestamp_now, batches: List[int] = _default_batch):
    print(min(cycle_list), max(cycle_list))
    for i_batch in batches:
        print(f"Start get ftable batch {i_batch}")

        path_save = f"{filepath}/rawdata_batch/batch{i_batch}"

        start_time = time.time()
        get_ftable(
            key_table=f"{path_save}/bid_hashed_batch{i_batch}.parquet",
            path_save=f"{path_save}/ftable_batch{i_batch}/",
            rawdata_path=rawdata_path,
            cycle_list=cycle_list,
            timestamp=timestamp,
        )

        print(f"Finished get ftable batch {i_batch} in {time.time() - start_time}s")


def do_process(current_state: str, finish_state: str, function_state_map: Dict[str, Tuple[Callable, list]], task: str = 'production'):
    if state_order_map[current_state] > state_order_map[finish_state]:
        raise Exception(f"The orders are get_atable -> get_dtable -> get_ftable -> done. {current_state} is after {finish_state}")

    end_state = next_state_map[finish_state]
    while current_state != end_state:
        start = time.time()
        func = function_state_map[current_state][0]
        param = function_state_map[current_state][1]
        print(f"start process {current_state}")

        return_value: Optional[Future] = func(*param)
        if task == 'backtest':
            if type(return_value) != list: return_value = [return_value]
            wait(return_value)

        print(f"{current_state} process done in {time.time() - start}seconds")

        current_state = next_state_map[current_state]


def backtest(user_input: dict, batches: Optional[str] = None):
    filepath = user_input["filepath"]
    rawdata_path = user_input["rawdata_path"]
    timestamp = user_input["timestamp"]
    current_state = user_input.get("start_state", "get_atable").lower()
    finish_state = user_input.get("finish_state", "done").lower()
    is_poc = user_input.get("is_poc", "false") == "true"
    dtable_file = user_input.get("dtable_file")

    dtable_file = f"{filepath}/{dtable_file}"
    key_table = pl.read_parquet(f"{filepath}/sample.parquet").rename({'bid': 'bid1'})
    print(key_table.shape)

    user_input_cycle = user_input.get("cycle")
    if "cycle_list" not in user_input:
        if user_input_cycle:
            min_cycle = user_input_cycle[0]
            max_cycle = user_input_cycle[1]
        else:
            min_cycle: date = key_table['t_observe'].min() - relativedelta(months=25)
            max_cycle: date = key_table['t_observe'].max()
            min_cycle = int(min_cycle.strftime("%Y%m"))
            max_cycle = int(max_cycle.strftime("%Y%m"))

    print(min_cycle, max_cycle)
    cycle_list = _get_cycle_list(min_cycle, max_cycle)

    if not (current_state in state_order_map.keys() and finish_state in state_order_map.keys()):
        raise Exception("start_state and finish_state must be one of [get_atable, get_dtable, get_ftable, done]")

    function_state_map = {
        "get_atable": (get_atable, [f"{filepath}/dtable.parquet", f"{filepath}/atable.parquet", rawdata_path, timestamp]),
        "get_dtable": (get_dtable, [key_table.lazy(), f"{filepath}/dtable.parquet", rawdata_path, timestamp, is_poc, dtable_file]),
        "get_ftable": (get_ftable, [f"{filepath}/dtable.parquet", f"{filepath}/ftable", rawdata_path, cycle_list, timestamp]),
    }

    do_process(current_state, finish_state, function_state_map, task='backtest')


def production(user_input: dict, batches: List[int] = []):
    user_input_cycle = user_input.get("cycle")
    if "cycle_list" not in user_input:
        if user_input_cycle:
            min_cycle = user_input_cycle[0]
            max_cycle = user_input_cycle[1]

        user_input["cycle_list"] = _get_cycle_list(min_cycle, max_cycle)

    filepath = user_input["filepath"]
    cycle_list = user_input["cycle_list"]
    rawdata_path = user_input["rawdata_path"]
    timestamp = user_input["timestamp"]
    update_bid = user_input.get("update_bid", 'false').lower() == 'true'
    paralel = user_input.get("paralel", 'false').lower() == 'true'
    current_state = user_input.get("start_state", "get_atable").lower()
    finish_state = user_input.get("finish_state", "done").lower()
    start_batch = user_input.get("start_batch", 0)
    finish_batch = user_input.get("finish_batch", 255)
    batches = batches or list(range(start_batch, finish_batch + 1))

    if not (current_state in state_order_map.keys() and finish_state in state_order_map.keys()):
        raise Exception(f"start_state and finish_state must be one of {list(state_order_map.keys())}")

    function_state_map = {
        "batch_bid": (batch_bid, [filepath, rawdata_path, update_bid, timestamp]),
        "get_atable": (get_atable_all, [filepath, rawdata_path, timestamp]),
        "get_dtable": (get_dtable_all, [filepath, rawdata_path, timestamp]),
        "get_ftable": (get_ftable_all, [filepath, rawdata_path, cycle_list, timestamp]),
    }
    if paralel:
        function_state_map["batch_bid"][1].extend([batches])
        function_state_map["get_atable"][1].extend([batches])
        function_state_map["get_dtable"][1].extend([batches])
        function_state_map["get_ftable"][1].extend([batches])
    else:
        function_state_map[current_state][1].extend([batches])

    do_process(current_state, finish_state, function_state_map)


def main(
        task: str, user_input: str,
        min_cycle: Optional[int] = None,
        max_cycle: Optional[int] = None,
        batches: Optional[str] = None
    ):
    global _connection_str

    user_input = json.load(open(user_input))["prepare"]
    pprint(user_input)

    _connection_str = _connection_str.format(**user_input["db_config"])

    timestamp = user_input.get("timestamp", timestamp_now)
    timestamp = timestamp.ljust(14, '0')
    user_input["timestamp"] = timestamp

    init_threads()

    if task == "backtest":
        backtest(user_input)

    if task == "production":
        production(user_input)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--task', type=str, help='Task of prepare either backtest, production', choices=["backtest", "production"])
    parser.add_argument('-ui', '--user_input', type=str, help='Path to user_input.json file', default=f"{_current_dir}/resources/user_input.json")
    parser.add_argument('--batches', type=str, help='Batches to be processed', default=None)
    parser.add_argument('--min_cycle', type=int, help='Min cycle for ftable', default=None)
    parser.add_argument('--max_cycle', type=int, help='Max cycle for ftable', default=None)
    args = parser.parse_args()
    main(args.task, args.user_input, args.min_cycle, args.max_cycle, args.batches)

"""
the orders are get_atable -> get_dtable -> get_ftable -> done
"""
