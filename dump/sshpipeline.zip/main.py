import paramiko
import time
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from queue import Queue, Empty
from threading import Thread, Lock, Event
import logging
import os
from pathlib import Path
from datetime import datetime
import json
from contextlib import contextmanager

MIN_MEMORY_THRESHOLD = 236
today_date = datetime.now().strftime("%Y-%m-%d")


@dataclass
class ServerConfig:
    hostname: str
    username: str
    password: str = None
    key_path: str = None
    port: int = 22
    weight: float = 1.0
    server_num: int = 0


class ServerStatus:
    def __init__(self, server: ServerConfig):
        self.server = server
        self.busy = False
        self.last_execution_start: Optional[datetime] = None
        self.last_execution_end: Optional[datetime] = None
        self.current_command: Optional[str] = None
        self.lock = Lock()
        self.available_event = Event()
        self.available_event.set()  # Initially available

    def mark_busy(self, command: str):
        with self.lock:
            self.busy = True
            self.last_execution_start = datetime.now()
            self.current_command = command
            self.available_event.clear()

    def mark_available(self):
        with self.lock:
            self.busy = False
            self.last_execution_end = datetime.now()
            self.current_command = None
            self.available_event.set()

    def wait_until_available(self, timeout: Optional[float] = None) -> bool:
        return self.available_event.wait(timeout=timeout)


class SSHConnection:
    def __init__(self, config: ServerConfig):
        self.config = config
        self.client = None
        self.connect()

    def connect(self):
        if self.client:
            return

        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        connect_kwargs = {
            'hostname': self.config.hostname,
            'username': self.config.username,
            'port': self.config.port
        }

        if self.config.key_path:
            connect_kwargs['key_filename'] = self.config.key_path
        elif self.config.password:
            connect_kwargs['password'] = self.config.password

        self.client.connect(**connect_kwargs)

    def close(self):
        if self.client:
            self.client.close()
            self.client = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

class ConnectionPool:
    def __init__(self, server_config: ServerConfig, pool_size: int = 5):
        self.server_config = server_config
        self.pool_size = pool_size
        self.available_connections = Queue()
        self.lock = Lock()
        self.total_connections = 0

    @contextmanager
    def get_connection(self):
        connection = self._get_or_create_connection()
        try:
            yield connection
        finally:
            self.available_connections.put(connection)

    def _get_or_create_connection(self) -> SSHConnection:
        try:
            return self.available_connections.get_nowait()
        except Empty:
            with self.lock:
                if self.total_connections < self.pool_size:
                    connection = SSHConnection(self.server_config)
                    self.total_connections += 1
                    return connection
            return self.available_connections.get()

    def close_all(self):
        while not self.available_connections.empty():
            connection = self.available_connections.get()
            connection.close()
            self.total_connections -= 1


class CommandQueue:
    """Thread-safe queue with monitoring capabilities"""
    def __init__(self):
        self._queue = Queue()
        self._active_commands = set()
        self._lock = Lock()
        self._completed_commands = 0
        self._failed_commands = 0
        self._command_events = {}  # Track command completion

    def put(self, command: Optional[str]) -> None:
        """Put a command in the queue and track it"""
        if command is not None:  # Don't track sentinel values
            with self._lock:
                self._active_commands.add(command)
                self._command_events[command] = Event()
        self._queue.put(command)

    def get(self, timeout: Optional[float] = None) -> Optional[str]:
        """Get a command from the queue"""
        try:
            return self._queue.get(timeout=timeout)
        except Empty:
            return None

    def task_done(self, command: Optional[str], success: bool = True) -> None:
        """Mark a task as done and update statistics"""
        self._queue.task_done()
        if command is not None:  # Don't track sentinel values
            with self._lock:
                if success:
                    self._active_commands.discard(command)
                    self._completed_commands += 1
                    if command in self._command_events:
                        self._command_events[command].set()
                else:
                    self._failed_commands += 1
                    self._queue.put(command)  # Retry failed command

    def wait_for_command(self, command: str, timeout: Optional[float] = None) -> bool:
        """Wait for a specific command to complete"""
        event = self._command_events.get(command)
        if event:
            return event.wait(timeout=timeout)
        return False

    @property
    def stats(self) -> Dict:
        """Get current queue statistics"""
        with self._lock:
            return {
                'active_commands': len(self._active_commands),
                'completed_commands': self._completed_commands,
                'failed_commands': self._failed_commands,
                'total_processed': self._completed_commands + self._failed_commands
            }

class SSHPipeline:
    def __init__(
            self,
            server_configs: List[ServerConfig],
            max_retries: int = 3, 
            pool_size: int = 5,
            server_wait_timeout: float = 300,
            log_wait_timeout: float = 120,
        ):
        self.servers = server_configs
        self.current_server_idx = 0
        self.lock = Lock()
        self.server_statuses = {
            server.hostname: ServerStatus(server) for server in self.servers
        }
        self.command_queue = CommandQueue()  # Using our enhanced queue
        self.max_retries = max_retries
        self.server_wait_timeout = server_wait_timeout
        self.log_wait_timeout = log_wait_timeout
        self.connection_pools = {
            server.hostname: ConnectionPool(server, pool_size)
            for server in self.servers
        }
        self.worker_status = {}  # Track worker thread status
        self.setup_logging()
        self.output_dir = Path(f"output/{today_date}")
        self.output_dir.mkdir(exist_ok=True)
        self._stop_event = Event()

    def setup_logging(self):
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(f"logs/ssh_pipeline_{datetime.now():%Y%m%d_%H%M%S}.log"),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def get_available_memory(self, connection: SSHConnection) -> int:
        stdin, stdout, stderr = connection.client.exec_command("free -m | awk '/^Mem:/ {print $7}'")
        available_memory = stdout.read().decode().strip()
        return int(available_memory)

    def check_available_memory(self, server: ServerConfig) -> Tuple[bool, int]:
        pool = self.connection_pools[server.hostname]
        with pool.get_connection() as connection:
            self.logger.info(f"Checking available memory on {server.hostname}")
            available_memory = self.get_available_memory(connection)
            return available_memory >= MIN_MEMORY_THRESHOLD, available_memory

    def get_next_available_server(self, command: str) -> Tuple[ServerConfig, ServerStatus]:
        fib1, fib2 = 2, 3

        while True:
            with self.lock:
                # Try each server in round-robin order
                attempts = 0
                initial_idx = self.current_server_idx

                while attempts < len(self.servers):
                    server = self.servers[self.current_server_idx]
                    status = self.server_statuses[server.hostname]
                    print(f"Current server idx: {self.current_server_idx}, server: {server.hostname}, attempts: {attempts}")

                    self.current_server_idx = (self.current_server_idx + 1) % len(self.servers)
                    attempts += 1

                    if not status.busy:
                        available, memory = self.check_available_memory(server)
                        if not available:
                            self.logger.info(f"Skipping {server.hostname} due to insufficient available memory: {memory}MB")
                            continue

                        status.mark_busy(command)
                        return server, status

                self.logger.info(f"All servers busy. Waiting for any server to become available...")
                
            # If we get here, all servers are busy. Wait for any server to become available
            available_server = None
            while available_server is None:
                for server in self.servers:
                    status = self.server_statuses[server.hostname]
                    if status.wait_until_available(timeout=self.server_wait_timeout):  # Short timeout to check other servers
                        with self.lock:
                            if not status.busy:  # Double-check under lock
                                available, memory = self.check_available_memory(server)
                                if not available:
                                    self.logger.info(f"Skipping {server.hostname} due to insufficient available memory: {memory}MB")
                                    time.sleep(min(fib2, 30))  # Fibonacci backoff
                                    fib1, fib2 = fib2, fib1 + fib2  # update fib 
                                    continue

                                status.mark_busy(command)
                                available_server = server
                                break

                if available_server:
                    return available_server, self.server_statuses[available_server.hostname]

    def write_output_to_file(self, server: ServerConfig, command: str, output: str, 
                            error: Optional[str] = None, status: str = "success"):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        output_file = self.output_dir / f"result_{server.server_num}.txt"
        try:
            with output_file.open("a") as f:
                f.write(f"\n{'='*80}\n")
                f.write(f"Timestamp: {timestamp}\n")
                f.write(f"Server: {server.hostname}\n")
                f.write(f"Command: {command}\n")
                f.write(f"Status: {status}\n")
                f.write(f"Output:\n{output}\n")
                if error:
                    f.write(f"Error:\n{error}\n")
                f.write(f"{'='*80}\n")
        except IOError as file_error:
            self.logger.error(f"Failed to write to output file: {file_error}")

    def execute_command_with_retry(self, server: ServerConfig, command: str) -> bool:
        status = self.server_statuses[server.hostname]
        retries = 0
        fib1, fib2 = 2, 3

        try:
            while retries <= self.max_retries:
                try:
                    pool = self.connection_pools[server.hostname]
                    with pool.get_connection() as connection:
                        self.logger.info(f"Executing on {server.hostname}: {command}")
                        stdin, stdout, stderr = connection.client.exec_command(command)
                        
                        output = stdout.read().decode()
                        error = stderr.read().decode()
                        exit_status = stdout.channel.recv_exit_status()
                        
                        if exit_status != 0:
                            self.logger.error(f"Command failed on {server.hostname}")
                            self.logger.error(error)
                            self.write_output_to_file(
                                server, command, output, error, status="failed"
                            )
                            # Check if the command was killed by the host server
                            if "Killed" in error or exit_status == 137:  # 137 is a common exit code for killed processes
                                self.logger.error(f"Command killed by host server on {server.hostname}")

                            retries += 1
                            if retries <= self.max_retries:
                                time.sleep(min(fib2, 30))  # Fibonacci backoff
                                fib1, fib2 = fib2, fib1 + fib2  # update fib
                            continue
                        
                        self.write_output_to_file(
                            server, command, output, status="success"
                        )
                        self.logger.info(f"Command completed successfully on {server.hostname}")
                        return True

                except Exception as e:
                    self.logger.error(f"Error on {server.hostname} (attempt {retries + 1}/{self.max_retries + 1}): {str(e)}")
                    retries += 1
                    if retries <= self.max_retries:
                        time.sleep(min(fib2, 30))  # Fibonacci backoff
                        fib1, fib2 = fib2, fib1 + fib2  # update fib


            self.logger.error(f"All retries failed for {server.hostname}")
            return False

        finally:
            status.mark_available()  # Always mark server as available when done

    def worker(self, worker_id: int, hostname: str):
        """Enhanced worker with better error handling and monitoring"""
        self.worker_status[worker_id] = {
            'hostname': hostname,
            'status': 'running',
            'current_command': None,
            'last_activity': datetime.now()
        }
        
        while not self._stop_event.is_set():
            try:
                command = self.command_queue.get(timeout=1.0)  # Use timeout to check stop_event
                if command is None:
                    break

                self.worker_status[worker_id].update({
                    'current_command': command,
                    'last_activity': datetime.now()
                })

                try:
                    server, status = self.get_next_available_server(command)
                    success = self.execute_command_with_retry(server, command)
                    self.command_queue.task_done(command, success)
                    
                    self.logger.info(f"Worker {worker_id} completed command: {command}")
                    self.log_queue_stats()  # Log queue statistics periodically

                except Exception as e:
                    self.logger.error(f"Worker {worker_id} encountered error: {str(e)}")
                    self.command_queue.task_done(command, False)

                self.worker_status[worker_id].update({
                    'current_command': None,
                    'last_activity': datetime.now()
                })

            except Empty:
                self.logger.info(f"Raise empty")
                continue
            except Exception as e:
                self.logger.error(f"Worker {worker_id} encountered unexpected error: {str(e)}")
                continue

        self.worker_status[worker_id]['status'] = 'stopped'

    def log_queue_stats(self):
        """Log current queue statistics"""
        stats = self.command_queue.stats
        self.logger.info(f"Queue stats: {json.dumps(stats, indent=2)}")

    def process_batch_commands(self, base_command: str, batch_range: range, num_workers: int = 3):
        """Enhanced batch processing with better monitoring"""
        self._stop_event.clear()
        workers: List[Thread] = []
        
        # Start worker threads
        for i in range(num_workers):
            worker = Thread(
                target=self.worker,
                args=(i, self.servers[i % len(self.servers)].hostname),
                name=f"Worker-{i}"
            )
            worker.daemon = True  # Allow program to exit if workers hang
            worker.start()
            workers.append(worker)

        try:
            # Add commands to queue
            for batch_num in batch_range:
                command = f"{base_command} --batches {batch_num} {batch_num + 1}"
                self.command_queue.put(command)

            # Add sentinel values to stop workers
            for _ in range(num_workers):
                self.command_queue.put(None)

            # Monitor progress
            while any(worker.is_alive() for worker in workers):
                self.log_queue_stats()
                self.log_worker_status()
                time.sleep(self.log_wait_timeout)  # Log status every x seconds

            # Wait for workers to finish
            for worker in workers:
                worker.join(timeout=30)  # Add timeout to prevent hanging

        except KeyboardInterrupt:
            self.logger.info("Received shutdown signal, stopping workers...")
            self._stop_event.set()
            for worker in workers:
                worker.join(timeout=30)
        finally:
            # Close all connection pools
            for pool in self.connection_pools.values():
                pool.close_all()

            # Final stats
            self.log_queue_stats()
            self.logger.info("Batch processing completed")

    def log_worker_status(self):
        """Log current status of all worker threads"""
        status_report = {
            worker_id: {
                'hostname': status['hostname'],
                'status': status['status'],
                'current_command': status['current_command'],
                'idle_time': (datetime.now() - status['last_activity']).total_seconds()
            }
            for worker_id, status in self.worker_status.items()
        }
        self.logger.info(f"Worker status: {json.dumps(status_report, indent=2)}")


def load_config(config_path: str) -> List[ServerConfig]:
    with open(config_path) as f:
        config_data = json.load(f)
    
    servers = []
    for idx, server_data in enumerate(config_data["servers"]):
        servers.append(ServerConfig(
            hostname=server_data["hostname"],
            username=server_data["username"],
            password=server_data.get("password"),
            key_path=server_data.get("key_path"),
            port=server_data.get("port", 22),
            weight=server_data.get("weight", 1.0),
            server_num=idx + 1
        ))
    
    return servers

def main():
    # Load server configurations from file
    servers = load_config("config.json")

    pipeline = SSHPipeline(
        servers,
        max_retries=3,
        pool_size=2,
        server_wait_timeout=30,  # timeout
        log_wait_timeout=15,  # log every x seconds
    )

    try:
        pipeline.process_batch_commands(
            base_command="python3 test.py",
            batch_range=range(0, 6, 2),
            num_workers=2
        )
    except KeyboardInterrupt:
        print("Shutting down gracefully...")


if __name__ == "__main__":
    main()