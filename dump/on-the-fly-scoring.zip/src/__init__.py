import logging
from fastapi import FastAPI
from datetime import datetime

from src.services import generate_score
from src.utils.constant import sentry_config
from src.models import GetScoreRequest, GetScoreResponse
from src.core.score import init_model, init_scorer, CBIClassifier


app = FastAPI()

if sentry_config['enabled']:
    import sentry_sdk
    from sentry_sdk.integrations.fastapi import FastApiIntegration
    from sentry_sdk.integrations.logging import LoggingIntegration

    sentry_sdk.init(
        dsn=sentry_config['dsn'],
        traces_sample_rate=0.6,
        profiles_sample_rate=0.6,
        integrations=[
            LoggingIntegration(
                level=logging.WARNING,
                event_level=logging.ERROR
            ),
            FastApiIntegration(
                transaction_style="url"
            )
        ]
    )


@app.on_event("startup")
def init_app():
    logging.info("Starting up the application")

    init_model()
    init_scorer()


@app.post("/api/get-score", response_model=GetScoreResponse)
async def get_score(request: GetScoreRequest):
    t_apply = request.t_apply
    if t_apply is None:
        t_apply = datetime.now().strftime("%Y-%m-%d")
    
    data = generate_score(
        version=request.version,
        product=request.product,
        bid=request.bid,
        t_apply=t_apply
    )

    breakpoint()
    return GetScoreResponse(
        data=data
    )
