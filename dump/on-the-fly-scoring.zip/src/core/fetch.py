import json
import math
import pandas as pd
import polars as pl
import connectorx as cx
from pathlib import Path
from datetime import datetime
from typing import List, Union, Tuple
from dateutil.relativedelta import relativedelta

from src.utils.database import get_connection_str
from src.utils.constant import resource_path, data_config as config


project_dir = Path(__file__).parents[1]
map_data_type = {
    'Utf8': pl.Utf8,
    'Float32': pl.Float32,
    'Float64': pl.Float64,
    'Int8': pl.Int8,
    'Int16': pl.Int16,
    'Int32': pl.Int32,
    'Int64': pl.Int64,
    'Date32': pl.Date,
    'Date': pl.Date,
    'Boolean': pl.Boolean
}
map_schema = {
    'dtable': json.load(open(f"{resource_path}/schema_dtable.json")),
    'ftable': json.load(open(f"{resource_path}/schema_ftable.json")),
    'atable': json.load(open(f"{resource_path}/schema_atable.json")),
}


def cast_schema(data: Union[pl.DataFrame, pl.LazyFrame], schema: dict) -> Union[pl.DataFrame, pl.LazyFrame]:
    data = (
        data
        .with_columns(
            [
                pl.col(x['name']).cast(map_data_type[x['data_type']], strict=False)
                for x in schema['fields']
                if x['data_type'] not in ['Date', 'Date32'] and x['name'] in data.columns
            ]
        )
    )

    return data


def get_data_batch(queries: List[str], batch_size: int = 5, type: str = 'polars') -> pl.DataFrame:
    '''
    type: str -> choices = {pandas, polars}
    '''
    n_batch = math.ceil(len(queries) / batch_size)

    data_list = []
    for i_batch in range(n_batch):
        query_this = queries[i_batch * batch_size : (i_batch + 1) * batch_size]
        data_list.append(pl.read_database(query_this, connection=get_connection_str()))

    return pl.concat(data_list)


def get_bimt(bid: str) -> pl.DataFrame:
    query = f"""
    SELECT
        bid1,
        member_type,
        member_code,
        cif
    FROM (
        SELECT 
            bid1,
            member_type,
            member_code,
            cif,
            row_number() over (partition by member_type, member_code, cif order by create_date desc, cycle_date desc) as rn
        FROM {config['schema']}.{config['dtable']}
        WHERE bid1 = '{bid}'
    ) a
    WHERE rn = 1
    """

    return pl.read_database(query, connection=get_connection_str())


def get_dtable(bid: str) -> Tuple[pl.DataFrame, pl.DataFrame]:
    data_schema = map_schema['dtable']
    query = f"""
    SELECT
        bid1,
        member_type,
        member_code,
        cif,
        create_date,
        dob,
        city,
        gender,
        marital_status,
        education,
        employment,
        cycle_date
    FROM {config['schema']}.{config['dtable']}
    WHERE bid1 = '{bid}' and member_code != 'M00018'
    """

    dtable = (
        pl.read_database(query, connection=get_connection_str())
        .sort(['create_date', 'cycle_date'])
        .unique(subset=['member_type', 'member_code', 'cif'], keep='last')
        .drop(['cycle_date'])
    )

    key_table = dtable.select(['member_type', 'member_code', 'cif', 'bid1']).unique()
    dtable = (
        dtable
        .with_columns([
            pl.col("gender").map_dict({"L": 1, "P": 2, "B": 3, "M": 4}, default=-1),
            pl.col('create_date').alias('create_date_raw'),
            pl.col("create_date").str.slice(0, 8).alias('create_date'),
        ])
        .pipe(cast_schema, schema=data_schema)
    )

    return dtable, key_table


def get_ftable(key_table: pl.DataFrame, t_observe: datetime, batch_size: int = 5) -> pl.DataFrame:
    data_schema = map_schema['ftable']
    max_cycle = (t_observe - relativedelta(month=1)).strftime("%Y%m")
    min_cycle = (t_observe - relativedelta(months=25)).strftime("%Y%m")
    bid = key_table[0]['bid1'].item()
    query = """
    SELECT
        member_type,
        member_code,
        cif,
        usage_type,
        cast(substr(cycle_date,1,6) as varchar) as cycle_date,
        account_number,
        condition,
        init_credit_date,
        maturity_date,
        latest_restructure_date,
        condition_date,
        interest_rate,
        init_limit,
        out_balance,
        defaultcode,
        dpd,
        collectability,
        principal_arrears,
        freq_arrears,
        credit_type,
        economic_sector,
        debtor_category,
        create_date,
        updated_date
    FROM {schema}.{table_name}
    WHERE cycle_date >= '{min_cycle}' and cycle_date <= '{max_cycle}'
        and member_type='{member_type}' and member_code='{member_code}' and cif='{cif}'
        and member_code not in ('810030', 'M00011')
    """

    queries = [
        query.format(
            schema=config['schema'],
            table_name=config['ftable'],
            min_cycle=min_cycle,
            max_cycle=max_cycle,
            member_type=data['member_type'],
            member_code=data['member_code'],
            cif=data['cif']
        )
        for data in key_table.to_dicts()
    ]

    return (
        get_data_batch(queries, batch_size)
        .sort(['cycle_date', 'create_date', 'updated_date'])
        .unique(subset=['member_type', 'member_code', 'cif', 'account_number', 'cycle_date'], keep='last')
        .drop(['create_date', 'updated_date'])
        .with_columns(pl.lit(bid).alias('bid1'))
        .pipe(cast_schema, schema=data_schema)
        .rename({"defaultcode": "default_code"})
    )


def get_atable(key_table: pl.DataFrame, batch_size: int = 10) -> pl.DataFrame:
    data_schema = map_schema['atable']
    query = """
    SELECT
        member_type,
        member_code,
        cif,
        account_number,
        collateral_type,
        reported_value
    FROM {schema}.{table_name}
    WHERE member_type='{member_type}' and member_code='{member_code}' and cif='{cif}'
    """

    queries = [
        query.format(
            schema=config['schema'],
            table_name=config['atable'],
            member_type=data['member_type'],
            member_code=data['member_code'],
            cif=data['cif']
        )
        for data in key_table.to_dicts()
    ]

    return get_data_batch(queries, batch_size).pipe(cast_schema, schema=data_schema)


def get_sample(bid: str, t_observe: datetime) -> pl.DataFrame:
    return pl.DataFrame(
        {'bid': [bid], 't_observe': [t_observe.date()], 'key': [f"{bid}@{t_observe.strftime('%Y-%m-%d')}"]}
    )


def get_feature(version: str, bid: str, t_apply: str) -> pd.DataFrame:
    table_name = config['feature_table'][version]
    filter_key = config['filter_key'][version]
    index_key = config['index_key'][version]

    query = f"""
        SELECT *
        FROM public.{table_name}
        WHERE {index_key}='{bid}'
            and {filter_key}='{t_apply}'
    """

    df = cx.read_sql(conn=get_connection_str(), query=query, return_type='pandas')
    return df
