from datetime import datetime
from pydantic import BaseModel, validator
from typing import List, Dict, Any, Optional


class RequestBaseModel(BaseModel):
    pass


class ResponseBaseModel(BaseModel):
    pass


class GetScoreRequest(RequestBaseModel):
    bid: str
    product: str
    version: str
    t_apply: Optional[str] = None

    @validator('t_apply')
    def validate_date_format(cls, v):
        try:
            datetime.strptime(v, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Incorrect t_apply format, should be YYYY-MM-DD")
        return v


class GetScoreResponse(ResponseBaseModel):
    data: List[Dict[str, Any]]
