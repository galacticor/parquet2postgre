from typing import List, Dict, Any

from src.core.fetch import get_feature
from src.core.score import get_score, get_score_multiple


def generate_score(version: str, product: str, bid: str, t_apply: str) -> List[Dict[str, Any]]:
    feature_data = get_feature(bid=bid, version=version, t_apply=t_apply)
    score_data = get_score(version, product, feature_data)
    breakpoint()

    return score_data.to_dicts()


def generate_score_multiple(version: str, products: List[str], bid: str, t_apply: str) -> List[Dict[str, Any]]:
    feature_data = get_feature(version=version, bid=bid, t_apply=t_apply)
    score_data = get_score_multiple(version, products, feature_data)


    return score_data.to_dicts()
