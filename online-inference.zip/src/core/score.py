import math
import joblib
from typing import List, Dict, Any, Union

import polars as pl
import pandas as pd
import numpy as np
from lightgbm import LGBMClassifier, Booster
from sklearn.calibration import CalibratedClassifierCV

from src.utils.constant import filepath, score_config as config

top_features: Dict[str, List[str]] = config["top_features"]
pd_ranges: Dict[str, Dict[str, Dict[str, List[str]]]] = config["pd_ranges"]
id_category_dict: Dict[str, Dict[str, int]] = config["id_category_dict"]
categorical_features: Dict[str, Dict[str, List[str]]] = config["categorical_features"]
model: Dict[str, Dict[str, list]] = config["model_dict"]
scorer: Dict[str, Dict[str, Any]] = config['scorer']


class CBIClassifier(object):
    def __init__(self, lgbm_model: LGBMClassifier, calibrated_model: CalibratedClassifierCV) -> None:
        self.lgbm_model = lgbm_model
        self.calibrated_model = calibrated_model

    def predict(self, x) -> np.ndarray:
        return self.calibrated_model.predict(x)
    
    def predict_proba(self, x) -> np.ndarray:
        return self.calibrated_model.predict_proba(x)

    @property
    def feature_name_(self) -> list:
        return self.lgbm_model.feature_name_

    @property
    def feature_importances_(self) -> np.ndarray:
        return self.lgbm_model.feature_importances_
    
    def __repr__(self):
        return f"{repr(self.lgbm_model)}\n{repr(self.calibrated_model)}"


class Scorer(object):
    def __init__(self, min_score=300, max_score=850, pdo=50, base_odds=20, base=600):
        self.A = pdo / math.log(2)
        self.B = base - math.log(base_odds) * self.A
        self.min_score = min_score
        self.max_score = max_score
        self.lower_proba = 1 / (math.exp((max_score - self.B) / self.A) + 1)
        self.upper_proba = 1 / (math.exp((min_score - self.B) / self.A) + 1)

        self.pdo = pdo
        self.base_odds = base_odds
        self.base = base

    def _to_score(self, proba):
        if proba < self.lower_proba:
            return self.max_score
        elif proba > self.upper_proba:
            return self.min_score
        else:
            return round(self.A * math.log((1 - proba) / proba) + self.B)

    def to_score(self, proba):
        if np.isscalar(proba):
            return self._to_score(proba)
        return np.vectorize(self._to_score)(proba)

    def _to_proba(self, score):
        return 1 / (1 + math.exp((score - self.B) / self.A))

    def to_proba(self, score):
        if np.isscalar(score):
            return self._to_proba(score)
        return np.vectorize(self._to_proba)(score)
    
    def __repr__(self) -> str:
        return f"Scorer(min_score={self.min_score}, max_score={self.max_score}, pdo={self.pdo}, base_odds={self.base_odds}, base={self.base}"


def init_scorer():
    global scorer

    for version in ['v1', 'v2']:
        for product_type in scorer[version]:
            scorer[version][product_type] = Scorer(**scorer[version][product_type])


def init_model():
    global model

    for version in ['v1', 'v2']:
        for product_type in model[version]:
            model[version][product_type] = joblib.load(f"{filepath}/{model[version][product_type]}")


def score(
    data: pd.DataFrame,
    scorer: Scorer,
    model: Union[CBIClassifier, LGBMClassifier, Booster],
) -> pd.DataFrame:
    ft_list: List[str]

    if type(model) == Booster:
        ft_list = model.feature_name()
    else:
        ft_list = model.feature_name_

    if type(model) == Booster:
        data['proba'] = model.predict(data[ft_list])
    else:
        data['proba'] = model.predict_proba(data[ft_list])[:,-1]

    data['score'] = scorer.to_score(data[f'proba'])
    return data


def get_score(version: str, product: str, data: Union[pl.DataFrame, pd.DataFrame]) -> pl.DataFrame:
    if type(data) == pl.DataFrame:
        data = data.to_pandas()

    to_cats = categorical_features[version][product]
    df_col_categories = data[to_cats].copy()
    data.loc[:, to_cats] = data.loc[:, to_cats].astype("category")
    data = score(
        data,
        scorer=scorer[version][product],
        model=model[version][product],
    )
    data[to_cats] = df_col_categories

    return build_data(version, product, pl.from_pandas(data))


def get_score_multiple(version: str, products: List[str], data: Union[pl.DataFrame, pd.DataFrame]) -> pl.DataFrame:
    if type(data) == pl.DataFrame:
        data = data.to_pandas()

    final_data_list = []
    for product in products:
        final_data_list.append(get_score(version, product, data.copy()))

    return pl.concat(final_data_list)


def get_pd(version: str, product: str, score: int) -> int:
    pd_ranges = pd_ranges[version][product]
    for upper_bound, bad_rate in zip(pd_ranges["upper_bound"], pd_ranges["bad_rate"]):
        if score <= upper_bound:
            return bad_rate


def build_data(version: str, product: str, data: pl.DataFrame) -> pl.DataFrame:
    top_feature: List[str] = top_features[version][product]
    id_category_dict = id_category_dict[version][product]
    rename_dict = {
        "bid1": "bid"
    }
    feature_map = {feat_name: f"feature_{i+1}" for i, feat_name in enumerate(top_feature)}
    feat_cast = [
        pl.col(f"feature_{i+1}").cast(pl.Float64)
        for i in range(len(top_feature))
    ]
    rename_dict.update(feature_map)

    breakpoint()

    final_data = (
        data
        .select(["bid1", "score", "periode_score"] + top_feature)
        .rename(rename_dict)
        .with_columns([
            pl.col("score").cast(pl.Int32),
            pl.lit(id_category_dict).alias("id_jenis_score").cast(pl.Int32),
            pl.lit(id_category_dict).alias("id_category").cast(pl.Int32),
            pl.col("score").apply(lambda x: get_pd(score=x, version=version, product=product)).alias("pd").cast(pl.Float32)
        ] + feat_cast)
        .select(['bid', 'score','feature_1','feature_2','feature_3','feature_4','feature_5', 'periode_score','id_jenis_score','id_category','pd'])
    )

    breakpoint()

    return final_data
