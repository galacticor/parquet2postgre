import json
from pathlib import Path


filepath = Path(__file__).parents[2]
resource_path = f"{filepath}/resources/"
params_config = json.load(open(f"{resource_path}/config.json"))
score_config = json.load(open(f"{resource_path}/score_config.json"))

sentry_config = params_config['sentry']
db_config = params_config['db']
data_config = params_config['data_info']
