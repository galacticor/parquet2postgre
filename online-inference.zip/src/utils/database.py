from typing import List, Union
from sqlalchemy import create_engine
from psycopg2.extensions import connection
from sqlalchemy.engine import Engine, Connection

from src.utils.constant import db_config as config

_engine: Engine = None
_connection_str: str = f"postgresql://{config['user']}:{config['password']}@{config['host']}:{config['port']}/{config['dbname']}"


def get_engine() -> Engine:
    global _engine

    if _engine is None:
        _engine = create_engine(_connection_str)

    return _engine


def get_connection_str() -> str:
    return _connection_str


def get_raw_connection() -> connection:
    return get_engine().raw_connection()


def get_connection() -> Connection:
    return get_engine().connect()


def execute_query(query: Union[str, List[str]]) -> None:
    """
    Execute query that not returning data
    """
    if type(query) == str:
        query = [query]

    connection = get_connection()
    transaction = connection.begin()
    try:
        for q in query:
            connection.execute(q)

        transaction.commit()
    except Exception as e:
        transaction.rollback()
        # log error first
        raise e
    finally:
        connection.close()
