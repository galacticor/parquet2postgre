import atexit
import logging
import logging.handlers
from queue import Queue
from typing import Callable

map_level_dict = {
    'DEBUG': logging.INFO,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'FATAL': logging.FATAL,
}


class Logger:
    def __init__(self) -> None:
        self.logger = self.create_logger()

    @staticmethod
    def close_queue(queue_listener: logging.handlers.QueueListener):
        queue_listener.stop()

    def create_logger(self, filepath: str, is_async: bool = False) -> logging.Logger:
        _logger = logging.getLogger(__name__)
        # _logger.setLevel(map_level_dict.get(level, logging.INFO))

        log_file = f"{filepath}/feature_script.log"
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)

        formatter = logging.Formatter('%(asctime)s - %(name)s -%(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)

        if is_async:
            queue = Queue(-1)
            queue_handler = logging.handlers.QueueHandler(queue)
            _logger.addHandler(queue_handler)

            _queue_listener = logging.handlers.QueueListener(queue, file_handler)
            _queue_listener.start()

            atexit.register(self.close_queue, _queue_listener)
        else:
            _logger.addHandler(file_handler)

        return _logger


    def get_logger(filepath: str = None, level: str = "INFO", is_async: bool = False) -> logging.Logger:
        global _logger

        if _logger is not None:
            return _logger
        
        if filepath is None:
            raise Exception('Please properly initialize logger before using.')

        create_logger(filepath, level, is_async)
        return _logger


def async_log(func: Callable):
    def wrapper(*args, **kwargs):
        _queue_listener.start()
        func(*args, **kwargs)
        _queue_listener.stop()

    return wrapper
