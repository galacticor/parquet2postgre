from src.core.score import CBIClassifier
from src import app

if __name__ == "__main__":
    import uvicorn
    
    # need to use this as the custom class CBIClassifier will result in error if we call uvicorn directly
    uvicorn.run("run:app", host="0.0.0.0", port=8001)  
