import logging
from datetime import datetime
from fastapi import FastAPI, HTTPException
from fastapi.responses import ORJSONResponse
from fastapi.staticfiles import StaticFiles

from src.models import (
    GetScoreRequest,
    GetScoreResponse,
    GetScoreMultipleRequest,
    GetScoreMultipleRespose,
)
from src.services import generate_score, generate_score_multiple
from src.core.score import ScoreService, CBIClassifier
from src.utils.database import Database
from src.utils.registry import registry_client_factory

static_path = "src/static"
_registry = registry_client_factory()

if _registry.get_config('sentry')['enabled']:
    import sentry_sdk
    from sentry_sdk.integrations.fastapi import FastApiIntegration
    from sentry_sdk.integrations.logging import LoggingIntegration

    sentry_sdk.init(
        dsn=_registry.get_config('sentry')['dsn'],
        traces_sample_rate=0.6,
        profiles_sample_rate=0.6,
        integrations=[
            LoggingIntegration(
                level=logging.WARNING,
                event_level=logging.ERROR
            ),
            FastApiIntegration(
                transaction_style="url"
            )
        ]
    )

app = FastAPI(
    default_response_class=ORJSONResponse,
)
app.mount("/static", StaticFiles(directory=static_path), name="static")


@app.on_event("startup")
async def init_app():
    _db = Database()
    _score_service = ScoreService()
    _registry = registry_client_factory()
    logging.info("Starting up the application")

    _score_service.init_model()
    _score_service.init_scorer()
    _registry.register()
    await _db.init_pool()


@app.on_event("shutdown")
async def shutdown_app():
    _db = Database()
    _registry = registry_client_factory()
    logging.info("Shutting down the application")

    _registry.deregister()
    await _db.close_pool()


@app.exception_handler(HTTPException)
async def custom_http_exception_handler(request, exc: HTTPException):
    if exc.status_code == 500:
        logging.error(f"Internal Server Error: {exc.detail}")
        return ORJSONResponse(
            status_code=500,
            content={"message": "Internal Server Error", "detail": exc.detail},
        )
    return ORJSONResponse(
        status_code=exc.status_code,
        content={"message": exc.detail},
    )


@app.get("/health-check")
def health_check():
    return  {"message": "OK"}


@app.post("/api/get-score", response_model=GetScoreResponse)
async def get_score(request: GetScoreRequest):
    t_apply = request.t_apply
    if t_apply is None:
        t_apply = datetime.now()

    try:
        data = await generate_score(
            version=request.version,
            products=request.products,
            bid=request.bid,
            t_apply=t_apply
        )

        return GetScoreResponse(
            message="success",
            data=data
        )
    except Exception as e:
        logging.error(f"Error: {e}")
        return HTTPException(status_code=500, detail=str(e))


@app.post("/api/get-score-multiple", response_model=GetScoreMultipleRespose)
async def get_score_multiple(request: GetScoreMultipleRequest):
    t_apply = request.t_apply
    if t_apply is None:
        t_apply = datetime.now()

    data = await generate_score_multiple(
        version=request.version,
        products=request.products,
        bids=request.bids,
        t_apply=t_apply
    )

    return GetScoreMultipleRespose(
        message="success",
        data=data
    )
