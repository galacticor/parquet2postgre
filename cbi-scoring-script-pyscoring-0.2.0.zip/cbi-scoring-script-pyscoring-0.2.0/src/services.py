from typing import List, Dict, Any
from datetime import date
from dateutil.relativedelta import relativedelta

from src.models import ScoreDataModel, ScoreDataModelMultiple
from src.core.score import ScoreService
from src.core.fetch import FetchService

fetch_service = FetchService()
score_service = ScoreService()


async def generate_score(version: str, products: List[str], bid: str, t_apply: date) -> List[ScoreDataModel]:
    min_cycle = t_apply - relativedelta(months=11)
    feature_data = await fetch_service.get_feature(version=version, bid=bid, min_cycle=str(min_cycle), max_cycle=str(t_apply))
    score_data = score_service.get_score(version, products, feature_data)

    return score_data[bid]


async def generate_score_multiple(version: str, products: List[str], bids: List[str], t_apply: str) -> List[ScoreDataModelMultiple]:
    min_cycle = t_apply - relativedelta(months=11)
    feature_data = await fetch_service.get_feature_multiple(version=version, bids=bids, min_cycle=str(min_cycle), max_cycle=str(t_apply))
    score_data_list = score_service.get_score(version, products, feature_data)

    result = [
        ScoreDataModelMultiple(bid=bid, data=score_data_list.get(bid, []))
        for bid in bids
    ]

    return result
