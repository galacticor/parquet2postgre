from pydantic import BaseModel
from typing import Optional, List


class ScoreDetail(BaseModel):
    periode: str
    score: int
    pd: float


class TopFeatures(BaseModel):
    feature_1: float
    feature_2: float
    feature_3: float
    feature_4: float
    feature_5: float


class ScoreDataModel(BaseModel):
    bid: str
    product: str
    score: int
    id_jenis_score: int
    id_category: int
    score_detail: List[ScoreDetail]
    top_features: TopFeatures


class ScoreDataModelMultiple(BaseModel):
    bid: str
    data: List[ScoreDataModel]
