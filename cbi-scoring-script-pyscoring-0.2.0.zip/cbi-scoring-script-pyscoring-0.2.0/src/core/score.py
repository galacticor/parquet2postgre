import math
import joblib
import numpy as np
import pandas as pd
pd.options.mode.chained_assignment = None

from collections import defaultdict
from typing import List, Dict, Any, Union

from lightgbm import LGBMClassifier, Booster
from sklearn.calibration import CalibratedClassifierCV

from src.core.models import ScoreDataModel, ScoreDetail, TopFeatures
from src.utils.singleton import SingletonMeta
from src.utils.registry import registry_client_factory
from src.utils.constant import filepath


class CBIClassifier(object):
    def __init__(self, lgbm_model: LGBMClassifier, calibrated_model: CalibratedClassifierCV) -> None:
        self.lgbm_model = lgbm_model
        self.calibrated_model = calibrated_model

    def predict(self, x) -> np.ndarray:
        return self.calibrated_model.predict(x)
    
    def predict_proba(self, x) -> np.ndarray:
        return self.calibrated_model.predict_proba(x)

    @property
    def feature_name_(self) -> list:
        return self.lgbm_model.feature_name_

    @property
    def feature_importances_(self) -> np.ndarray:
        return self.lgbm_model.feature_importances_
    
    def __repr__(self):
        return f"{repr(self.lgbm_model)}\n{repr(self.calibrated_model)}"


class Scorer(object):
    def __init__(self, min_score=300, max_score=850, pdo=50, base_odds=20, base=600):
        self.A = pdo / math.log(2)
        self.B = base - math.log(base_odds) * self.A
        self.min_score = min_score
        self.max_score = max_score
        self.lower_proba = 1 / (math.exp((max_score - self.B) / self.A) + 1)
        self.upper_proba = 1 / (math.exp((min_score - self.B) / self.A) + 1)

        self.pdo = pdo
        self.base_odds = base_odds
        self.base = base

    def _to_score(self, proba):
        if proba < self.lower_proba:
            return self.max_score
        elif proba > self.upper_proba:
            return self.min_score
        else:
            return round(self.A * math.log((1 - proba) / proba) + self.B)

    def to_score(self, proba):
        if np.isscalar(proba):
            return self._to_score(proba)
        return np.vectorize(self._to_score)(proba)

    def _to_proba(self, score):
        return 1 / (1 + math.exp((score - self.B) / self.A))

    def to_proba(self, score):
        if np.isscalar(score):
            return self._to_proba(score)
        return np.vectorize(self._to_proba)(score)
    
    def __repr__(self) -> str:
        return f"Scorer(min_score={self.min_score}, max_score={self.max_score}, pdo={self.pdo}, base_odds={self.base_odds}, base={self.base}"


class ScoreService(metaclass=SingletonMeta):
    def __init__(self) -> None:
        self._config = registry_client_factory().get_config("score")
        self.top_features: Dict[str, List[str]] = self._config["top_features"]
        self.pd_ranges: Dict[str, Dict[str, Dict[str, List[str]]]] = self._config["pd_ranges"]
        self.id_category_dict: Dict[str, Dict[str, int]] = self._config["id_category_dict"]
        self.categorical_features: Dict[str, Dict[str, List[str]]] = self._config["categorical_features"]
        self.model: Dict[str, Dict[str, list]] = self._config["model_dict"]
        self.scorer: Dict[str, Dict[str, Any]] = self._config['scorer']

    def init_scorer(self):
        for version in ['v1', 'v2']:
            for product_type in self.scorer[version]:
                self.scorer[version][product_type] = Scorer(**self.scorer[version][product_type])

    def init_model(self):
        for version in ['v1', 'v2']:
            for product_type in self.model[version]:
                self.model[version][product_type] = joblib.load(f"{filepath}/{self.model[version][product_type]}")

    def score(
        self,
        data: pd.DataFrame,
        scorer: Scorer,
        model: Union[CBIClassifier, LGBMClassifier, Booster],
    ) -> pd.DataFrame:
        if isinstance(model, Booster):
            proba = model.predict(data[model.feature_name()])
        else:
            proba = model.predict_proba(data[model.feature_name_])[:, -1]

        data['proba'] = proba
        data['score'] = scorer.to_score(data['proba'])

        return data

    def get_score(self, version: str, products: list, data: pd.DataFrame) -> Dict[str, List[ScoreDataModel]]:
        final_data_list = []
        for product in products:
            to_cats = self.categorical_features[version][product]
            df_col_categories = data[to_cats].copy()
            data.loc[:, to_cats] = data.loc[:, to_cats].astype("category")
            data = self.score(
                data,
                scorer=self.scorer[version][product],
                model=self.model[version][product],
            )
            data[to_cats] = df_col_categories
            final_data_list.append(self.build_data(version, product, data))

        final_data = pd.concat(final_data_list, axis=0)
        return self.serialize_data(final_data)

    def get_pd(self, version: str, product: str, score: int) -> int:
        pd_range = self.pd_ranges[version][product]
        for upper_bound, bad_rate in zip(pd_range["upper_bound"], pd_range["bad_rate"]):
            if score <= upper_bound:
                return float(bad_rate)

    def build_data(self, version: str, product: str, data: pd.DataFrame) -> pd.DataFrame:
        top_feature: List[str] = self.top_features[version][product]
        id_category = self.id_category_dict[version][product]

        data = data[['bid', 'score', 'periode'] + top_feature]
        data.loc[:, 'product'] = product
        data.loc[:, 'id_jenis_score'] = id_category
        data.loc[:, 'id_category'] = id_category
        data.loc[:, 'pd'] = self.get_pd_vectorized(version, product, data['score'])
        data.loc[:, 'periode'] = data['periode'].dt.strftime('%y%m')

        rename_dict = {feature: f'feature_{i+1}' for i, feature in enumerate(top_feature)}
        data = data.rename(columns=rename_dict)

        return data

    def get_pd_vectorized(self, version: str, product: str, scores: pd.Series) -> pd.Series:
        pd_range = self.pd_ranges[version][product]
        upper_bounds = pd_range["upper_bound"]
        bad_rates = pd_range["bad_rate"]

        # vectorized
        pd_series = pd.cut(scores, bins=[0] + upper_bounds, labels=bad_rates).astype(float)
        return pd_series

    def serialize_data(self, data: pd.DataFrame) -> Dict[str, List[ScoreDataModel]]:
        return_dict = defaultdict(list)
        grouped = data.sort_values('id_category', ascending=False).groupby(['bid', 'product'])

        for (bid, product), data_product in grouped:
            data_product = data_product.sort_values('periode', ascending=False)
            first_row = data_product.iloc[0]

            id_jenis_score = first_row['id_jenis_score']
            id_category = first_row['id_category']
            score = first_row['score']
            top_features = TopFeatures(
                feature_1=first_row['feature_1'],
                feature_2=first_row['feature_2'],
                feature_3=first_row['feature_3'],
                feature_4=first_row['feature_4'],
                feature_5=first_row['feature_5'],
            )
            score_detail = [
                ScoreDetail(
                    periode=row['periode'],
                    score=row['score'],
                    pd=row['pd'],
                )
                for _, row in data_product.iterrows()
            ]

            score_data_model = ScoreDataModel(
                bid=bid,
                product=product,
                score=score,
                top_features=top_features,
                id_jenis_score=id_jenis_score,
                id_category=id_category,
                score_detail=score_detail,
            )

            return_dict[bid].append(score_data_model)

        return return_dict
