import math
import asyncio
import numpy as np
import pandas as pd
from typing import List

from src.utils.database import Database
from src.utils.singleton import SingletonMeta
# from src.utils.constant import data_config as config
from src.utils.registry import registry_client_factory

BATCH_SIZE_BID = 20


class FetchService(metaclass=SingletonMeta):
    def __init__(self) -> None:
        self._db: Database = Database()
        self._registry = registry_client_factory()
        self._config = self._registry.get_config("data_info")

    def transform_to_numpy(self, data: List[dict], version: str) -> np.ndarray:
        filter_key = self._self._config['filter_key'][version]
        index_key = self._self._config['index_key'][version]

        column_names = list(data[0].keys())
        data = [tuple(row.values()) for row in data]

        for i, name in enumerate(column_names):
            if name == filter_key: column_names[i] = 'periode'
            if name == index_key: column_names[i] = 'bid'

        dt = np.dtype([(name, 'O') for name in column_names])
        data = np.array(data, dtype=dt)
        data = np.where(data == None, -1, data)
        data = np.nan_to_num(data, nan=-1)

        return data
    
    def transform_to_pandas(self, data: List[dict], version: str) -> pd.DataFrame:
        filter_key = self._config['filter_key'][version]
        index_key = self._config['index_key'][version]
        df = pd.DataFrame(data, columns=data[0].keys())

        df = df.where(pd.notnull(df), -1)
        df = df.fillna(-1)
        df = df.rename(columns={filter_key: 'periode', index_key: 'bid'})

        return df

    async def get_feature(self, version: str, bid: str, min_cycle: str, max_cycle: str) -> pd.DataFrame:
        table_name = self._config['feature_table'][version]
        filter_key = self._config['filter_key'][version]
        index_key = self._config['index_key'][version]
        schema = self._config["schema"]

        query = f"""
            SELECT *
            FROM {schema}.{table_name}
            WHERE {index_key}='{bid}' 
                and {filter_key} >= date('{min_cycle}')
                and {filter_key} <= date('{max_cycle}')
        """

        data = await self._db.fetch(query)
        if len(data) == 0:
            raise Exception(f'Feature data with bid={bid} with cycle({min_cycle} - {max_cycle}) not found.')

        return self.transform_to_pandas(data, version)

    async def get_feature_multiple(self, version: str, bids: List[str], min_cycle: str, max_cycle: str) -> pd.DataFrame:
        table_name = self._config['feature_table'][version]
        filter_key = self._config['filter_key'][version]
        index_key = self._config['index_key'][version]
        schema = self._config["schema"]

        query = """
            SELECT *
            FROM {schema}.{table_name}
            WHERE {index_key} in {bids}
                and {filter_key} >= date('{min_cycle}')
                and {filter_key} <= date('{max_cycle}')
        """

        n_batch = math.ceil(len(bids) / BATCH_SIZE_BID)
        queries = [
            query.format(
                schema=schema,
                table_name=table_name,
                index_key=index_key,
                filter_key=filter_key,
                min_cycle=min_cycle,
                max_cycle=max_cycle,
                bids="(" + str(bids[i_batch * BATCH_SIZE_BID : (i_batch + 1) * BATCH_SIZE_BID] )[1:-1] + ")",
            )
            for i_batch in range(n_batch)
        ]

        data_list = await asyncio.gather(*[self._db.fetch(query) for query in queries])
        data = []
        for row in data_list:
            data += row

        return self.transform_to_pandas(data, version)
