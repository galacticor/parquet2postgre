from datetime import date
from pydantic import BaseModel
from typing import Optional, List

from src.core.models import ScoreDataModel, ScoreDataModelMultiple

class RequestBaseModel(BaseModel):
    pass


class ResponseBaseModel(BaseModel):
    message: str


class GetScoreRequest(RequestBaseModel):
    bid: str
    products: List[str]
    version: str
    t_apply: Optional[date] = None


class GetScoreMultipleRequest(RequestBaseModel):
    bids: List[str]
    products: List[str]
    version: str
    t_apply: Optional[date] = None


class GetScoreResponse(ResponseBaseModel):
    data: List[ScoreDataModel]


class GetScoreMultipleRespose(ResponseBaseModel):
    data: List[ScoreDataModelMultiple]
