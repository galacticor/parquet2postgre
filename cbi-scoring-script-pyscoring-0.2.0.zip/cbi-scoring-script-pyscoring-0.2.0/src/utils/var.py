import time
import contextvars
from typing import Any


# add trace id and request time in every request
trace_id_var: contextvars.ContextVar[Any] = contextvars.ContextVar("trace_id", default=None)
request_start_time_var: contextvars.ContextVar[Any] = contextvars.ContextVar(
    "request_start_time", default=time.time()
)
