import os
import json
import logging.config
from nacos import NacosClient
from abc import abstractmethod

from src.utils.singleton import SingletonMeta
from src.utils.logging import LOGGING_CONFIG_DEFAULTS
from src.utils.constant import resource_path

logging.config.dictConfig(LOGGING_CONFIG_DEFAULTS)
logger = logging.getLogger(__name__)

NACOS_URL = os.environ.get("nacos_config_server_addr", "172.22.131.49:8848")
NACOS_NAMESPACE = os.environ.get(
    "nacos_config_namespace", "008025c9-a258-4db2-9e2a-ed0d1e0a104b"
)
NACOS_USERNAME = os.environ.get("nacos_username", "nacos")
NACOS_PASSWORD = os.environ.get("nacos_password", "nacos")

NACOS_SERVICE_NAME = os.environ.get("NACOS_SERVICE_NAME", "cbi-scoring-service")
NACOS_GROUP = os.environ.get("NACOS_GROUP", "ds")
NACOS_SERVICE_INSTANCE = os.environ.get("NACOS_SERVICE_INSTANCE", "127.0.0.1:8000")
NACOS_DATA_ID = os.environ.get("NACOS_DATA_ID", "data_id")


class RegistryClient(metaclass=SingletonMeta):
    @abstractmethod
    def get_config(self):
        pass

    @abstractmethod
    def register(self):
        pass

    @abstractmethod
    def deregister(self):
        pass


class NacosRegistryClient(RegistryClient):
    def __init__(self) -> None:
        self.nacos_client = NacosClient(
            NACOS_URL, NACOS_NAMESPACE, username=NACOS_USERNAME, password=NACOS_PASSWORD
        )
        self.config: dict = None

    def get_config(self, group_key: str):
        if self.config is None:
            self.config = json.loads(self.nacos_client.get_config(NACOS_DATA_ID, NACOS_GROUP))

        return self.config[group_key]

    def register(self):
        self.nacos_client.add_naming_instance(
            NACOS_SERVICE_NAME,
            ip=NACOS_SERVICE_INSTANCE.split(":")[0],
            port=int(NACOS_SERVICE_INSTANCE.split(":")[1]),
            group_name=NACOS_GROUP
        )

    def deregister(self):
        self.nacos_client.remove_naming_instance(
            NACOS_SERVICE_NAME,
            ip=NACOS_SERVICE_INSTANCE.split(":")[0],
            port=int(NACOS_SERVICE_INSTANCE.split(":")[1]),
            group_name=NACOS_GROUP
        )


class LocalRegistryClient(RegistryClient):
    def __init__(self) -> None:
        self.config: dict = None

    def get_config(self, group_key: str):
        if self.config is None:
            self.config = json.load(open(f"{resource_path}/config.json"))
            self.config['score'] = json.load(open(f"{resource_path}/score_config.json"))

        return self.config[group_key]

    def register(self):
        print("Registering local instance...")

    def deregister(self):
        print("De-registering local instance...")


def registry_client_factory() -> RegistryClient:
    if os.getenv('APP_ENV', 'local') == 'local':
        return LocalRegistryClient()
    else:
        return NacosRegistryClient()
