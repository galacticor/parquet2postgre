import json
from pathlib import Path


filepath = Path(__file__).parents[2]
resource_path = f"{filepath}/resources/"
