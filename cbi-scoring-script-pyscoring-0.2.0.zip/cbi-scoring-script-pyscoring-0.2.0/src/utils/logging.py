import os
import sys
import time
import json

import datetime
import logging.config
from typing import Any, Dict, Tuple, List

from src.utils import var

RESERVED_ATTRS: Tuple[str, ...] = (
    "args",
    "asctime",
    "created",
    "exc_info",
    "exc_text",
    "filename",
    "funcName",
    "getMessage",
    "levelname",
    "levelno",
    "lineno",
    "module",
    "msecs",
    "message",
    "msg",
    "name",
    "pathname",
    "process",
    "processName",
    "relativeCreated",
    "stack_info",
    "thread",
    "threadName",
    "color_message",
)


def get_record_extra(
    record: logging.LogRecord, reserved: Tuple[str, ...]
) -> List[Dict[str, Any]]:
    """
    Get extra attributes from LogRecord object into extra list
    :param record: logging.LogRecord
    :param reserved: dict or list with reserved keys to skip
    """
    extra_list = []
    for key, value in record.__dict__.items():
        # this allows to have numeric keys
        if key not in reserved and not (
            hasattr(key, "startswith") and key.startswith("_")
        ):
            extra_list.append({"name": key, "value": value})
    return extra_list


class JSONFormatter(logging.Formatter):
    def __init__(self, context: str = "context", *args: Any, **kwargs: Any):
        super(JSONFormatter, self).__init__(*args, **kwargs)

        self._context_attr = context
        self._pid = os.getpid()

    @staticmethod
    def format_timestamp(log_time: float) -> str:
        return datetime.datetime.fromtimestamp(log_time).isoformat()

    def format(self, record: logging.LogRecord, serialize: bool = True) -> str:
        extra_list = get_record_extra(record, RESERVED_ATTRS)
        msg = record.getMessage()
        msg = msg if len(msg) <= 4096 else msg[:4096]
        # Deal with tracebacks
        exc = ""
        if record.exc_info:
            # Cache the traceback text to avoid converting it multiple times
            # (it's constant anyway)
            if not record.exc_text:
                record.exc_text = self.formatException(record.exc_info)
        if record.exc_text:
            if exc[-1:] != "\n":
                exc += "\n"
            exc += record.exc_text
        if record.stack_info:
            if exc[-1:] != "\n":
                exc += "\n"
            exc += self.formatStack(record.stack_info)
        exc = exc.lstrip("\n").replace("\n", "<br>")
        return_results = ""
        if isinstance(var.trace_id_var.get(), list):
            for idx, trace_id in enumerate(var.trace_id_var.get()):
                return_results = (
                    return_results
                    + json.dumps(
                        {
                            "timestamp": self.format_timestamp(record.created),
                            "level": record.levelname,
                            "message": msg,
                            "logger": record.name,
                            "worker_pid": self._pid,
                            "filename": record.filename,
                            "lineno": record.lineno,
                            "traceback": exc if len(exc) > 0 else "",
                            "processName": record.processName,
                            "process": record.process,
                            "threadName": record.threadName,
                            "thread": record.thread,
                            "extra": extra_list,
                            "cost_time": time.time()
                            - var.request_start_time_var.get()[idx],
                            "trace_id": trace_id,
                        }
                    )
                    + "\n"
                )
        else:
            message = {
                "timestamp": self.format_timestamp(record.created),
                "level": record.levelname,
                "message": msg,
                "logger": record.name,
                "worker_pid": self._pid,
                "filename": record.filename,
                "lineno": record.lineno,
                "traceback": exc if len(exc) > 0 else "",
                "processName": record.processName,
                "process": record.process,
                "threadName": record.threadName,
                "thread": record.thread,
                "extra": extra_list,
                "cost_time": time.time() - var.request_start_time_var.get(),
                "trace_id": var.trace_id_var.get(),
            }
            return_results = json.dumps(message)

        return return_results


LOGGING_CONFIG_DEFAULTS: Dict[str, Any] = dict(
    version=1,
    disable_existing_loggers=False,
    # formmatters=JSONFormatter,
    formatters={"generic": {"class": "src.utils.logging.JSONFormatter"}},
    handlers={
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "generic",
            "stream": sys.stdout,
        },
        #        "file": {"class": "logging.handlers.TimedRotatingFileHandler", "formatter": "generic", "filename": 'logs/log.out', 'when': 'midnight',
        #                 'interval': 1, 'backupCount': 30}
    },
    loggers={"": {"level": "INFO", "handlers": ["console"], "propagate": True}},
)
