import asyncpg
from asyncpg import Pool, Connection, Record
from typing import List, Union

from src.utils.singleton import SingletonMeta
from src.utils.registry import registry_client_factory


class Database(metaclass=SingletonMeta):
    _connection_str: str = "postgresql://{user}:{password}@{host}:{port}/{dbname}"

    def __init__(self) -> None:
        self._config = registry_client_factory().get_config("db")
        self._connection_str = self._connection_str.format(
            user=self._config["user"],
            password=self._config["password"],
            host=self._config["host"],
            port=self._config["port"],
            dbname=self._config["dbname"]
        )
        self._pool: Pool = None

    async def init_pool(self) -> Pool:
        self._pool = await asyncpg.create_pool(
            user=self._config["user"],
            password=self._config["password"],
            database=self._config["dbname"],
            host=self._config["host"],
            port=self._config["port"],
            min_size=self._config.get("min_size", 5),
            max_size=self._config.get("max_size", 10) 
        )

        return self._pool

    async def close_pool(self) -> None:
        if self._pool is not None:
            await self._pool.close()

    def get_connection_str(self) -> str:
        return self._connection_str

    async def fetch(self, query: str, *args) -> List[dict]:
        if self._pool is None:
            await self.init_pool()

        async with self._pool.acquire() as connection:
            result = await connection.fetch(query, *args)

        return result

    async def execute(self, query: Union[str, List[str]]) -> None:
        """
        Execute query that not returning data
        """
        if self._pool is None:
            await self.init_pool()

        if type(query) == str:
            query = [query]

        connection: Connection = await self._pool.acquire()
        transaction = connection.transaction()
        await transaction.start()
        try:
            for q in query:
                await connection.execute(q)

            transaction.commit()
        except Exception as e:
            await transaction.rollback()
            # log error first
            raise e
        finally:
            await self._pool.release(connection)
