import os
from src.core.score import CBIClassifier
from src import app

if __name__ == "__main__":
    import uvicorn

    num_workers = 1
    if os.getenv('APP_ENV', 'local').lower() in ['production', 'prod']:
        num_workers = os.cpu_count()

    # need to use this as the custom class CBIClassifier will result in error if we call uvicorn directly
    uvicorn.run("run:app", host="0.0.0.0", port=8000, workers=num_workers)
